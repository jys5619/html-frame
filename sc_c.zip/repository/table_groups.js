[ {"name":"FB"   , "comments":"GCAMP", "owner":"O_GCAM"}
, {"name":"TOBE_IF" , "comments":"TOBE INTERFACE", "owner":"O_GCAM"} 
, {"name":"TOBE_TP" , "comments":"TOBE TEMP", "owner":"O_GCAM"} 
, {"name":"TOBE_MT" , "comments":"TOBE MASTER", "owner":"O_GCAM"} 
, {"name":"ASIS" , "comments":"ASIS GCAMP", "owner":"CJCAMPUS"} 
, {"name":"FDV" , "comments":"ASIS GCAMP", "owner":"CJCAMPUS"} 
]