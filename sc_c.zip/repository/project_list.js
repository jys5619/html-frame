[ {"gubun": "BATCH", "id": "HRDR001", "name": "프로젝트1", "type": "BATCH_R", "source": ["Service", "Dao", "Vo", "Mapper"]}
, {"gubun": "BATCH", "id": "HRDR002", "name": "프로젝트2", "type": "BATCH_R", "source": ["Service", "Dao", "Vo", "Mapper"]}
]
