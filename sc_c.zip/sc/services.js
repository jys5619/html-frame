angular.module('sc').factory('scDb', function() {
    var storage = {
        groups: [],
        tables: [],
        columns: [],
        indexes: [],
        setGropups: function(data) {
            angular.copy(data, storage.groups) || [];
        },
        getGroups: function() {
            return storage.groups;
        },
        setTables: function(data) {
            angular.copy(data, storage.tables) || [];
        },
        appendTables: function(data) {
            storage.tables.concat(data);
        },
        getTables: function() {
            return storage.tables;
        },
        setColumns: function(data) {
            angular.copy(data, storage.columns) || [];
        },
        appendColumns: function(data) {
            storage.columns.concat(data);
        },
        getColumns: function(data) {
            return storage.columns;
        },
        setIndexes: function(data) {
            angular.copy(data, storage.indexes) || [];
        },
        appendIndexes: function(data) {
            storage.indexes.concat(data);
        },
        getIndexes: function(data) {
            return storage.indexes;
        },
        selectColumns: function(tableinfo) {

            var newColumns = [];

            storage.columns.forEach(function(item) {
                if ( item.owner == tableinfo.owner  && item.table == tableinfo.name  ) {
                    var col = JSON.parse(JSON.stringify(item));
                    col.checked = true;
                    col.index = null;
                    newColumns.push(col);
                    if ( newColumns.length > 0 && (item.owner != tableinfo.owner || item.table != tableinfo.name)) {
                        return;
                    }
                }
            });
            
            return newColumns;
        },
        selectColumn: function(tableName, columnName) {
            var col = null;
            for ( var i = 0; i < storage.columns.length; i++ ) {
                var item = storage.columns[i];
                if ( item.column == columnName  && item.table == tableName  ) {
                    col = JSON.parse(JSON.stringify(item));
                    col.checked = true;
                    col.index = null;
                    return col;
                }
            }
            
            return col;
        },
        selectIndexes: function(tableinfo) {

            var newIndexes = [];

            storage.indexes.forEach(function(item) {

                if ( item.owner == tableinfo.owner  && item.table == tableinfo.name  ) {
                    var idx = JSON.parse(JSON.stringify(item));
                    newIndexes.push(idx);
                    if ( newIndexes.length > 0 && (item.owner != tableinfo.owner || item.table != tableinfo.name)) {
                        return;
                    }
                }
              
            });
            
            return newIndexes;
        }
    };
    
    return storage;
});

angular.module('sc').factory('scSourceInput', function() {
    var storage = {
        sources: [],
        getSources: function() {
            return storage.sources;
        },
        addSource: function(source) {
            storage.sources.push(source);
        }
    };
    
    return storage;
});

angular.module('sc').factory('scTableProcesser', function() {
    var storage = {
        tables: [],
        getTables: function() {
            return storage.tables;
        },
        addTable: function(table) {
            storage.tables.push(table);
        }
    };
    
    return storage;
});

angular.module('sc').factory('scModules', function() {
    var storage = {
        inputs: [],
        outputs: [],
        getInputs: function() {
            return storage.inputs;
        },
        addInput: function(obj) {
            var input = obj;
            storage.inputs.push(input);
        },
        getInput: function(str) {
            var input_module = [];
            storage.inputs.forEach(function(item) {
                if ( item.is(str) ) {
                    input_module = item;
                }
            });
            
            return input_module;
        },
        getOutputs: function() {
            return storage.outputs;
        },
        addOutput: function(obj) {
            var output = obj;
            storage.outputs.push(output);
        }
    };
    
    return storage;
});
