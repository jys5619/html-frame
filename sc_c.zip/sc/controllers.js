
function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

angular.module('sc', ['angular.filter']).controller('ScCtrl', function($scope, $http, scDb, scSourceInput, scTableProcesser, scModules) {

    $http.get("./repository/table_groups.js", {header : {'Content-Type' : 'application/json; charset=UTF-8'}}).then( 
        function(response) {
            scDb.setGropups(response.data);
            $scope.db.groups = scDb.getGroups();
        }
      , function(response) {
            alert("Something went wrong");
        }
    );
    
    $http.get("./repository/table_infos.js", {header : {'Content-Type' : 'application/json; charset=UTF-8'}}).then( 
        function(response) {
            scDb.setTables(response.data);
            $scope.db.tables = scDb.getTables();
        }
      , function(response) {
            alert("Something went wrong");
        }
    );

    $http.get("./repository/table_columns.js", {header : {'Content-Type' : 'application/json; charset=UTF-8'}}).then( 
        function(response) {
            scDb.setColumns(response.data);
            $scope.db.columns = scDb.getColumns();
        }
      , function(response) {
            alert("Something went wrong");
        }
    );

    $http.get("./repository/table_indexes.js", {header : {'Content-Type' : 'application/json; charset=UTF-8'}}).then( 
        function(response) {
            scDb.setIndexes(response.data);
            $scope.db.indexes = scDb.getIndexes();
        }
      , function(response) {
            alert("Something went wrong");
        }
    );

    // input
    $scope.db = {};
    $scope.db.groups = scDb.getGroups();
    $scope.db.tables = scDb.getTables();
    $scope.db.columns = scDb.getColumns();
    $scope.db.indexes = scDb.getIndexes();

    $scope.search = function() {
        if ( $scope.search.target === "name" ) {
            $scope.searchTableFilter = function(table) {
                var isGood = false;
                if ( typeof($scope.search.group) == "undefined") {
                    $scope.search.group = "";
                }
                if ( typeof($scope.search.text) == "undefined") {
                    $scope.search.text = "";
                }
                if ( $scope.search.group == "" && $scope.search.text == "" ) {
                    isGood = true;
                } else if  ( $scope.search.group == "" ) {
                    isGood = table.name.indexOf($scope.search.text) !== -1 || 
                             table.comments.indexOf($scope.search.text) !== -1;
                } else if ( $scope.search.text == "" ) {
                    isGood = table.group == $scope.search.group;
                } else {
                    isGood = (table.group == $scope.search.group &&
                              (table.name.indexOf($scope.search.text) !== -1 || 
                               table.comments.indexOf($scope.search.text) !== -1
                              )
                             );
                }
                
                return isGood;
            };
        } else {
            $scope.searchTableFilter = {group: $scope.search.group, columns: $scope.search.text};
        }
    }
    
    scSourceInput.addSource("AAA");
    scSourceInput.addSource("BBB");

    $scope.input = {};
    $scope.input.source = {};
    $scope.input.source.list = scSourceInput.getSources();
    $scope.input.source.items = [ {group:"AAA", title:"111", source:"SELECT *"}
                                , {group:"AAA", title:"222"    , source:"INSERT *"}
                                , {group:"BBB", title:"333"    , source:"INSERT *"}
                                , {group:"BBB", title:"444"    , source:"INSERT *"}
                                ];
    $scope.input.source.changeTitle = function() {
        console.log(typeof($scope.input.source.title));
        $scope.input.source.edit.title = $scope.input.source.title.title;
    };
    
    // Process
    $scope.processer = {};
    $scope.processer.table = {};
    $scope.processer.source = {};
    $scope.processer.table.tables = scTableProcesser.getTables();
    
    $scope.addTableTables = function(tableinfo) {
        if ( tableinfo != null && tableinfo != "" ) {
            var table = JSON.parse(tableinfo);
            
            table.columns = scDb.selectColumns(table);
            table.indexes = scDb.selectIndexes(table);
            
            angular.forEach(table.indexes, function(index) {
                index.columnlist = [];
                angular.forEach(index.columns, function(indexColumn) {
                    
                    var col = table.columns.find(function(element) {
                           return element.column == indexColumn;
                    });

                    index.columnlist.push(col);

                });
            });

            scTableProcesser.addTable(table);
            $scope.processer.table.target = table;
            
            $scope.processer.table.target.allchecked = true;
            if ( table.indexes.length > 0 ) {
                $scope.processer.table.target.index = table.indexes[0];
                $scope.processer.table.target.previndex = table.indexes[0];

                angular.forEach(table.indexes[0].columnlist, function(column, $index) {
                    column.index = $index + 1;
                });
            };
        }
    };
    $scope.cnahgeIndex = function(table) {
        angular.forEach(table.previndex.columnlist, function(column, $index) {
           column.index = null;
        });
        
        angular.forEach(table.index.columnlist, function(column, $index) {
           column.index = $index + 1;
        });
        
        $scope.processer.table.target.previndex = table.index;
    };
    
    $scope.set_indexcolor = function(index) {

        if ( index > 0) {
            return {background: "cornflowerblue"};
        }   
    };
    
    $scope.toggleAllCheck = function(allcheck, checklist) {
        if ( allcheck ) {
            allcheck = true;
        } else {
            allcheck = false;
        }
        angular.forEach(checklist, function(item) {
            item.checked = allcheck;
        });
    };
    
    $scope.updateAllCheck = function(tg, checklist) {
        var count = 0;
        angular.forEach(checklist, function(item) {
            if ( item.checked ) {
                count++;
            }
        });

        if ( checklist.length == count ) {
            tg.allchecked = true;
        } else {
            tg.allchecked = false;
        }
    };
    
    $scope.setResultHeight = function(h) {
        if ( $scope.resultHeight + h > 200 ) {
            $scope.resultHeight = $scope.resultHeight + h ;
        }
    }
    
    $scope.setResultDataHeight = function() {
        if ( $scope.output.target.result.split("\n").length * 22 > 200 ) {
            $scope.resultHeight = $scope.output.target.result.split("\n").length * 22;
        }
    }
    
    angular.forEach(gv_modules_input, function(module) {
        module.scope = $scope;
        scModules.addInput(module);
    });
    
    $scope.processInput = function() {
        var str = $scope.input.source.edit.source;
        var module_input = scModules.getInput(str);
        if ( module_input == null ) {
            return [];
        }

        var table = module_input.process(str);
        
        for ( var i = 0; i < table.columns.length; i++ ) {
            var col = table.columns[i];
            if ( col.table != "" && col.column != "" ) {
                var outputCol = scDb.selectColumn(col.table, col.column);
                if ( outputCol != null ) {
                    col.comment = outputCol.comment;
                    col.type = outputCol.type;
                    col.len = outputCol.len;
                    col.scale = outputCol.scale;
                    col.nullable = outputCol.nullable;
                }
            }
        }
        table.indexes = [];
        $scope.processer.source.target = table;
    };
    
    $scope.output = {};
    $scope.output.modules = scModules.getOutputs();
    $scope.output.target  = $scope.output.modules[0];
    
    angular.forEach(gv_modules_output, function(module) {
        module.scope = $scope;
        module.result = "";
        scModules.addOutput(module);
    });
    
    $scope.output = {};
    $scope.output.modules = scModules.getOutputs();
    $scope.output.target  = $scope.output.modules[0];
});

