
gv_modules_output[gv_modules_output.length] = 
{ name: "MERGE"
 , options: [ {id:"INTO_PREFIX"  , desc:"INTO 앞문자"        , value:"#{"   , display:true , type: "TEXT"}
            , {id:"INTO_SUFFIX"  , desc:"INTO 뒤문자"        , value:"}"   , display:true , type: "TEXT"}
            ]
 , fnGetSource: function () {
     var table = this.scope.processer[this.scope.input.target].target;

	var code       = "";
	var col        = null;
	var tblName    = "";
	var varType    = "";
	var varUType   = "";
    
	var maxLen     = null;
	
	var mybatisStr = "";
	var selectStr  = "";
	var intoStr    = "";
	var fromStr    = "";
	var whereStr   = "";

    var idx = 0;
     
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "INTO_PREFIX";
    });     
    var into_prefix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "INTO_SUFFIX";
    });     
    var into_suffix = this.scope.output.target.options[idx].value;

    // length
	maxLen = getMaxLen(table);

    if ( typeof table.name == "undefined" ) {
        table.name = "";
    }

	tblName = table.name;

    var sql = ""
    var tableNameUpperCamel = table.name.toCase("Camel");
    var tableName           = table.name;
    var wherePkList         = "";
    var updateColumnList    = "";
    var insertColumnList    = "";
    var insertValueList     = "";


    if ( table.index != null ) {
        for ( var i = 0; i < table.index.columnlist.length; i++ ) {
            if (wherePkList != "") {
                wherePkList +=" AND ";
            }
            col = table.index.columnlist[i];

            wherePkList = wherePkList + col.column + " = " + into_prefix + col.column.toCase("camel") + into_suffix;
        }
    }

	// source
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
		    
		    
		    if ( col.column == "IF_SYNC_DTTM" || col.column == "IF_CRUD_FLAG" ) {
		        continue;
		    }
		    
		    // updateColumnList
            
            if ( !table.index.columnlist.some(pk => pk.column === col.column) ) {
                if (updateColumnList != "" ) {
    				updateColumnList += "\n     , ";
    			}
                if ( col.nullable == 'Y' ) {
                    null_str = ", jdbcType=" + fnGetType(col, "jdbcType");
                    updateColumnList = updateColumnList + (col.column.rpad(maxLen.column, ' ') + " = " + into_prefix + (col.column.toCase("camel").rpad(maxLen.column, ' ') + null_str + into_suffix));
                } else {
                    updateColumnList = updateColumnList + (col.column.rpad(maxLen.column, ' ') + " = " + into_prefix + (col.column.toCase("camel") + into_suffix));
                }
            }
            
            // insertColumnList, insertValueList
			if ( insertColumnList != "" ) {
				insertColumnList += "\n     , ";
				insertValueList  += "\n     , ";
			}
			
            insertColumnList = insertColumnList + col.column;
            
            if ( col.nullable == 'Y' ) {
                null_str = ", jdbcType=" + fnGetType(col, "jdbcType");
                insertValueList = insertValueList + into_prefix + col.column.toCase("camel").rpad(maxLen.column, ' ') + null_str + into_suffix;
            } else {
                insertValueList = insertValueList + into_prefix + col.column.toCase("camel") + into_suffix;
            }
		}
	}
	
    sql = " MERGE /* Mapper.insert#TABLE_NAME_UPPER_CAMEL# */\n"
		+ "  INTO #TABLE_NAME#\n"
		+ " USING DUAL\n"
        + "    ON (#WHERE_PK_LIST#)\n"
		+ "  WHEN MATCHED THEN\n"
		+ "UPDATE\n"
		+ "   SET #UPDATE_COLUMN_LIST#\n"
        + "     , IF_SYNC_DTTM         = TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')\n"
        + "     , IF_CRUD_FLAG         = 'U'\n"
		+ "  WHEN NOT MATCHED THEN\n"
	    + "INSERT\n"
        + "     ( #INSERT_COLUMN_LIST#\n"
        + "     , IF_SYNC_DTTM\n"
        + "     , IF_CRUD_FLAG\n"
        + "     )\n"
        + "VALUES\n"
        + "     ( #INSERT_VALUE_LIST#\n"
        + "     , TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')\n"
        + "     , 'I'\n"
        + "     )";

	sql = sql.replace("#TABLE_NAME_UPPER_CAMEL#", tableNameUpperCamel);
	sql = sql.replace("#TABLE_NAME#", tableName);
	sql = sql.replace("#WHERE_PK_LIST#", wherePkList);
	sql = sql.replace("#UPDATE_COLUMN_LIST#", updateColumnList);
	sql = sql.replace("#INSERT_COLUMN_LIST#", insertColumnList);
	sql = sql.replace("#INSERT_VALUE_LIST#", insertValueList);
    
     
	code = sql;
     
     
	this.scope.output.target.result = code;
  }
};



