gv_modules_input[gv_modules_input.length] = 
{ name: "TABLE_INFO"
, is: function(str) {
      return str.split("\t").length == 6;
  }
, process: function(str) {
	var data      = [];
	var content   = "";
	var selectStr = "";
	var fromStr   = "";
	var arrTmp    = null;
	var col       = "";
	var cols      = [];
    var tbls      = [];
    var tableName = "";
    var tableNames = {};
	var aliasName = "";
	var comment = "";
	var type = "";
	var collen = 0;
	var colscale = 0;
	var colnullable = "";
	content = str
	
    // column
    var rows = content.split("\n");
    
    for ( var r = 0; r < rows.length; r++ ) {
        cols = rows[r].split("\t");
    
        for ( var i = 0; i < cols.length; i++ ) {
            tableName = "";
            aliasName = "";
            col = cols[0].trim();
            comment = cols[1].trim();
            type = cols[2].trim();
            collen = cols[3];
            colscale = cols[4];
            colnullable = cols[5].trim();
            
            data[data.length] = {"table":tableName, "alias":aliasName, "column":col, "checked": true, "comment": comment, "type": type, "len": collen, "scale": colscale, "nullable": "Y"};
        }
    }
    var table = {};
    table.columns = data;
    return table;
  }
}
