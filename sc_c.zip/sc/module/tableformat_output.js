
gv_modules_output[gv_modules_output.length] = 
{ name: "TABLE_FORMAT"
 , options: [ {id:"SPLIT_STR"     , desc:"구분자"  , value:"\t" , display:true , type: "TEXT"}
            , {id:"NAME_PRINT"    , desc:"컬럼명"  , value:true , display:true, type: "CHECKBOX"}
            , {id:"COMMENT_PRINT" , desc:"한글명"  , value:true    , display:true , type: "CHECKBOX"}          
            , {id:"TYPE_PRINT"    , desc:"타입"     , value:true , display:true , type: "CHECKBOX"}
            , {id:"LEN_PRINT"     , desc:"길이"     , value:true , display:true , type: "CHECKBOX"}
            , {id:"SCALE_PRINT"     , desc:"소수점"  , value:true , display:true , type: "CHECKBOX"}
            , {id:"NULLABLE_PRINT", desc:"NUMMABLE"   , value:true , display:true , type: "CHECKBOX"}
  ]
 , fnGetSource: function (target, processer) {
    var table = this.scope.processer[this.scope.input.target].target;
    var code       = "";
	var col        = null;
	var tblName    = "";
	var space      = 0;
	var maxLen     = null;
	var tableStr      = "";
	
	var varType    = "";
	var varUType   = "";
	
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "SPLIT_STR";
    });
    var split_str = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "NAME_PRINT";
    });
    var name_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "COMMENT_PRINT";
    });
    var comment_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "TYPE_PRINT";
    });
    var type_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "LEN_PRINT";
    });
    var len_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "SCALE_PRINT";
    });
    var scale_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "NULLABLE_PRINT";
    });
    var nullable_print = this.scope.output.target.options[idx].value;
     
	// length
	maxLen = getMaxLen(table);
     
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
		    
		    if ( name_print ) {
    		    tableStr += col.column + split_str;
		    }
		    
		    if ( comment_print ) {
    		    tableStr += col.comment + split_str;
		    }
		    if ( type_print ) {
    		    tableStr += col.type + split_str;
		    }
		    if ( len_print ) {
    		    tableStr += col.len + split_str;
		    }
		    if ( scale_print ) {
    		    tableStr += col.scale + split_str;
		    }
		    if ( nullable_print ) {
    		    tableStr += col.nullable + split_str;
		    }
		    
		    if ( tableStr.endWith("\t") ) {
		        tableStr = tableStr.substr(0, tableStr.length - 1);
		    }
		    
		    tableStr += "\n";
		}
    }
    

    code = tableStr;
	this.scope.output.target.result = code;
 }
};
	