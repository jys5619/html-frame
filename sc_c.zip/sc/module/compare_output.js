
gv_modules_output[gv_modules_output.length] = 
{ name: "COMPARE_OUTPUT"
 , options: [ {id:"JSON"        , desc:"JSON"           , value:"{}"   , display:true , type: "TEXTAREA"}
  ]
 , fnGetSource: function (target, processer) {
    var table = this.scope.processer[this.scope.input.target].target;
    var code       = "";
	var col        = null;
	var tblName    = "";
	var space      = 0;
	var maxLen     = null;
	var varType    = "";
	var varUType   = "";
    var emptyColList      = "";
    var emptyJsonList      = "";
    var jsonObj    = "";
    var keylist = null;
    var orderedJson = "";
	
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "JSON";
    });
    var json = this.scope.output.target.options[idx].value;
    jsonObj = JSON.parse(json);
    keylist = Object.keys(jsonObj);
	// length
	maxLen = getMaxLen(table);
	
	var cols = table.columns.map(function(col) {
	    return col.column;
	});

	for ( var i = 0; i < cols.length; i++ ) {
		col = cols[i];
		if ( !keylist.includes(col) ) {
            emptyColList += (col + "\n");
		}
		
		if ( jsonObj[col] != null ) {
		    orderedJson += (col + "\t[" + jsonObj[col] + "]\n");
		} else {
		    orderedJson += (col + "\n");
		}
    }

	for ( var i = 0; i < keylist.length; i++ ) {
		k = keylist[i];
		if ( !cols.includes(k) ) {
            emptyJsonList += (k + "\n");
		}
    }
    


    code = "JSON에 없는 COLUMN 목록:\n" + emptyColList + "\n\nCOLUMN에 없는JSON 목록:\n" + emptyJsonList + "\n\n정렬:\n" + orderedJson;
	this.scope.output.target.result = code.trim();
 }
};

function getFaceData(col) {
    var str = "";
    if ( col.type == "FLOAT" ) {
        str = randomNumber(0, 10000) + "." + randomNumber(0, 100);
    } else if ( col.type == "NUMBER" ) {
        if (col.scale > 0) {
            str = randomNumber(0, 10000) + "." + randomNumber(0, 100);
        } else if (col.len > 9) {
            str = randomNumber(0, 90000);
        } else {
            str = randomNumber(0, 90000);
        }
    } else {
        if ( col.len > 10 ) {
            str = randomString(col.len / 2 - randomNumber(0, col.len / 2));
        } else {
            if ( col.len > 40 ) {
                str = randomString(20);
            } else {
                str = randomString(col.len / 2);
            }
        }
    }
        
    return str;
}


