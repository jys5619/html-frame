
gv_modules_output[gv_modules_output.length] = 
{ name: "UPDATE"
 , options: [ {id:"COMMENT_PRINT", desc:"주석출력"           , value:false , display:true , type: "CHECKBOX"}
            , {id:"VALUE_PREFIX", desc:"VALUE절 변수 앞문자"  , value:"#{" , display:true, type: "TEXT"}
            , {id:"VALUE_SUFFIX", desc:"VALUE절 변수 뒷문자"  , value:"}"    , display:true , type: "TEXT"}
            , {id:"WHERE_ONE"    , desc:"WHERE 1 = 1 출력"   , value:false , display:true , type: "CHECKBOX"}
            , {id:"WHERE_PREFIX", desc:"WHERE절 변수 앞문자"  , value:"#{"  , display:true , type: "TEXT"}
            , {id:"WHERE_SUFFIX", desc:"WHERE절 변수 뒷문자"  , value:"}"   , display:true , type: "TEXT"}
            , {id:"OWNER_PRINT" , desc:"OWNER 출력여부"      , value:false  , display:true , type: "CHECKBOX"}
            , {id:"MYBATIS_PRINT", desc:"Mybatis XML 출력"  , value:true   , display:true , type: "CHECKBOX"}
            , {id:"CAMEL_CASE"   , desc:"Camel 형식 출력"    , value:true   , display:true , type: "CHECKBOX"}
  ]
 , fnGetSource: function (target, processer) {
    var table = this.scope.processer[this.scope.input.target].target;
    var code       = "";
	var col        = null;
	var tblName    = "";
	var space      = 0;
	var maxLen     = null;
	var updateStr  = "";
	var whereStr   = "";
	var varType    = "";
	var varUType   = "";
    var varLen     = 0;
    var varIdxLen  = 0;
    var null_str   = "";
	
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "COMMENT_PRINT";
    });
    var comment_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "VALUE_PREFIX";
    });
    var value_prefix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "VALUE_SUFFIX";
    });
    var value_suffix = this.scope.output.target.options[idx].value;
    
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "WHERE_ONE";
    });     
    var where_one = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "WHERE_PREFIX";
    });     
    var where_prefix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "WHERE_SUFFIX";
    });     
    var where_suffix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "OWNER_PRINT";
    });
    var owner_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "MYBATIS_PRINT";
    });     
    var mybatis_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "CAMEL_CASE";
    });     
    var camel_case = this.scope.output.target.options[idx].value;
    
	// length
	maxLen = getMaxLen(table);

     
    if ( camel_case ) {
        varType = "camel";
        varUType = "Camel";
        varLen = maxLen.columnCamel;
        varIdxLen = maxLen.indexCamel;
    } else {
        varType = "lower";
        varUType = "upper";
        varLen = maxLen.column;
        varIdxLen = maxLen.index;
    }
     
    // length 
    space = value_prefix.length + value_suffix.length;
	
	if ( space < where_prefix.length + where_suffix.length ) {
	    space = where_prefix.length + where_suffix.length;  
	}
	
	space = space + (maxLen.name * 2) + 4;
	
	tblName = getFullName(owner_print, table.owner, table.name, "");
    
	if ( space < tblName.length ) {
		space = tblName.length;
	}
	
	if ( maxLen.comment < table.comments.bytelength() ) {
	    maxLen.comment = table.comments.bytelength();
	}

    // source
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
			if (updateStr == "" ) {
                if ( comment_print ) {
				    updateStr += "UPDATE /* " + table.name.toCase(varUType) + "Mapper.select" + table.name.toCase(varUType) + " */ " + tblName + "    /* " + table.comments.byterpad(maxLen.comment, ' ') + " */\n   SET ";
                } else {
                    updateStr += "UPDATE /* " + table.name.toCase(varUType) + "Mapper.select" + table.name.toCase(varUType) + " */ " + tblName + "\n   SET ";
                }
			} else {
				updateStr += "     , ";
			}

            if ( comment_print ) {
                updateStr = updateStr + (col.column.rpad(maxLen.column, ' ') + " = " + value_prefix + (col.column.toCase(varType) + value_suffix).rpad(varLen + value_suffix.length, ' ')).rpad(space, ' ') 
                          + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n"
                          ;
            } else {
                if ( col.nullable == 'Y' ) {
                    null_str = ", jdbcType=" + fnGetType(col, "jdbcType");
                    updateStr = updateStr + (col.column.rpad(maxLen.column, ' ') + " = " + value_prefix + (col.column.toCase(varType).rpad(varLen, ' ') + null_str + value_suffix)) + "\n";
                } else {
                    updateStr = updateStr + (col.column.rpad(maxLen.column, ' ') + " = " + value_prefix + (col.column.toCase(varType) + value_suffix)) + "\n";
                }
            }
		}
	}
	
    if ( table.index != null ) {
        for ( var i = 0; i < table.index.columnlist.length; i++ ) {
            if (whereStr == "") {
                if ( where_one ) {
                    whereStr =" WHERE 1 = 1\n   AND ";
                } else {
                    whereStr =" WHERE ";
                }
            } else {
                    whereStr +="   AND ";
            }
            col = table.index.columnlist[i];

            if ( comment_print ) {
                whereStr = whereStr + col.column.rpad(maxLen.index, ' ') + " = " + where_prefix + (col.column.toCase(varType) + where_suffix).rpad(varLen + where_suffix.length, ' ') + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
            } else {
                whereStr = whereStr + col.column.rpad(maxLen.index, ' ') + " = " + where_prefix + (col.column.toCase(varType) + where_suffix).rpad(varLen + where_suffix.length, ' ') + "\n";
            }
        }
    }
     
	code = updateStr + whereStr;
	
    if (mybatis_print) {
        mybatisStr = '\n    <!-- ' + table.comments + ' 수정 -->\n' + '    <update id="update' + table.name.toCase(varUType) + '" parameterType="' + table.name.toCase(varUType) + 'Vo">\n'
        code.split("\n").forEach(function (line) {
            if ( line.trim().length > 0 ) {
                mybatisStr = mybatisStr + "        " + line + "\n";
            }
        });
        
        mybatisStr = mybatisStr + '    </update>\n'
        
        code = mybatisStr;
    }
     
	this.scope.output.target.result = code;
 }
};
	