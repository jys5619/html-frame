gv_modules_input[gv_modules_input.length] = 
{ name: "SELECT"
, is: function(str) {
      return str.trim().toUpperCase().startWith("SELECT");
  }
, process: function(str) {
	var data      = [];
	var content   = "";
	var selectStr = "";
	var fromStr   = "";
	var arrTmp    = null;
	var col       = "";
	var cols      = [];
    var tbls      = [];
    var tableName = "";
    var tableNames = {};
	var aliasName = "";
	content = str.replaceRange("/*", "*/", " ");
	content = content.replaceRange("//", "\r\n", " ");
	content = content.replaceRange("'", "'", " _NONE_ ");
	content = content.loopCutRange("(", ")", " _NONE_ ");
	content = content.replace(/\r\n/gi, " ");
	content = content.replace(/\t/gi, " ");
	content = " " + content + " ";
	content = content.removeDblSpace();

	var selectIdx = content.indexOf(" SELECT ");
	var fromIdx   = content.indexOf(" FROM "  );
	var whereIdx  = content.indexOf(" WHERE " );
	
	if ( fromIdx < 0  ) {
		selectStr = content.substr(selectIdx + 8, content.length - selectIdx - 8);
	} else {
		selectStr = content.substr(selectIdx + 8, fromIdx - selectIdx - 8);

         if ( whereIdx < 0 ) {
             fromStr = content.substr(fromIdx + 6, content.length - fromIdx - 6);
         } else {
             fromStr = content.substr(fromIdx + 6, whereIdx - fromIdx - 6);
         }
    }
    
    // table
    if ( fromStr.trim() != "" && fromStr.indexOf(",") < 0 ) {
        tableName = fromStr.trim();
        tableNames["_NONE_"] = tableName;
    } else if ( fromStr.trim() != "" && fromStr.indexOf(",") > 0 ) {
        var tableNameTmps = [];
        var tableNamesplit = [];
        
        tableNameTmps = fromStr.split(",");
        for ( var i = 0; i < tableNameTmps.length; i++ ) {
            tableName = tableNameTmps[i].trim();
            
            if ( tableName.indexOf(" ") > 0 ) {
                tableNamesplit = tableName.split(" ");
                tableNames[tableNamesplit[1]] = tableNamesplit[0];
            }
        }
    } else {
        tableNames["_NONE_"] = "";
    }

	console.log(selectStr);
	console.log(fromStr);
	
    // column
    cols = selectStr.split(",");

    for ( var i = 0; i < cols.length; i++ ) {
        arrTmp = cols[i].trim().split(" ");
        col = arrTmp[arrTmp.length - 1].trim();
        colTemp = arrTmp[0].trim();
        
        if ( col == "_NONE_" ) {
            col = "";
        }
        
        if ( col.indexOf(".") > -1 ) {
            var pos = col.indexOf(".");
            col = col.substr(pos + 1, col.length - pos - 1);
        }
        
        if ( Object.keys(tableNames).length > 0 && colTemp.indexOf(".") > 0 ) {
            aliasName = colTemp.substr(0, colTemp.indexOf("."));
            tableName = tableNames[aliasName];
        } else {
            tableName = tableNames["_NONE_"];
            aliasName = "";
        }
        
        data[data.length] = {"table":tableName, "alias":aliasName, "column":col, "checked": true, "comment": "", "type": "NONE", "len": 0, "scale": 0, "nullable": "Y"};
    }
    var table = {};
    table.columns = data;
    return table;
  }
}
