
gv_modules_output[gv_modules_output.length] = 
{ name: "TABLE_CRATE"
 , options: [ {id:"OWNER_NAME"   , desc:"OWNER"             , value:"O_GCAM"   , display:true , type: "TEXT"}
            , {id:"TABLE_NAME"   , desc:"TABLE NAME"        , value:""   , display:true , type: "TEXT"}
            , {id:"TABLE_COMMENT", desc:"TABLE COMMENT"        , value:""   , display:true , type: "TEXT"}
            ]
 , fnGetSource: function () {
     var table = this.scope.processer[this.scope.input.target].target;

	var code       = "";
	var col        = null;
    
	var maxLen     = null;
    var lenLen     = 0;
    var idx = 0;
     
    var tc_str = "";
    var col_str = "";
    var desc_str = "";
    var pk_index_str = "";
       
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "OWNER_NAME";
    });
    var owner_name = this.scope.output.target.options[idx].value;
   
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "TABLE_NAME";
    });
    var table_name = this.scope.output.target.options[idx].value;
   
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "TABLE_COMMENT";
    });
    var table_comment = this.scope.output.target.options[idx].value;
   
    if ( table_name == "" ) {
        table_name = table.name.toUpperCase();
    }
     
    if ( table_comment == "" ) {
        table_comment = table.comments;
    }
     
     tc_str = ""
            + "/*******************************************************************************************************************************\n"
            + " *\n"
            + " * #TABLE_NAME_UPPER# : #TABLE_NAME_DESC#\n"
            + " *\n"
            + " ******************************************************************************************************************************/\n"
            + "\n"
            + "-- DROP TABLE\n"
            + "DROP TABLE #OWNER#.#TABLE_NAME_UPPER# CASCADE CONSTRAINTS;\n"
            + "\n"
            + "-- CREATE TABLE\n"
            + "CREATE TABLE #OWNER#.#TABLE_NAME_UPPER# \n"
            + "#LOOP_COLUMN#"
            + "TABLESPACE TS_GCAM_D\n"
            + "PCTFREE    10\n"
            + "INITRANS   1\n"
            + "MAXTRANS   255\n"
            + "STORAGE (\n"
            + "    INITIAL     64 K\n"
            + "    NEXT        1 M\n"
            + "    MINEXTENTS  1\n"
            + "    MAXEXTENTS  UNLIMITED\n"
            + ")\n"
            + "LOGGING\n"
            + "NOCACHE\n"
            + "MONITORING\n"
            + "NOPARALLEL\n"
            + ";\n"            
            + "#PK_INDEX#\n"
            + "\n"
            + "COMMENT ON TABLE #OWNER#.#TABLE_NAME_UPPER# IS '#TABLE_NAME_DESC#';\n"
            + "#LOOP_COLUMN_COMMENT#"
            + "CREATE SYNONYM GCAM.#TABLE_NAME_UPPER# FOR #OWNER#.#TABLE_NAME_UPPER#;\n"
            + "GRANT DELETE ON #OWNER#.#TABLE_NAME_UPPER# TO GCAM;\n"
            + "GRANT UPDATE ON #OWNER#.#TABLE_NAME_UPPER# TO GCAM;\n"
            + "GRANT SELECT ON #OWNER#.#TABLE_NAME_UPPER# TO GCAM;\n"
            + "GRANT INSERT ON #OWNER#.#TABLE_NAME_UPPER# TO GCAM;\n"
            ;
     /*
ALTER TABLE CJCAMPUS.TB_IF_HR_JOBCODE2 ADD CONSTRAINT TB_IF_HR_JOBCODE2_PK PRIMARY KEY (COMPANY,EMPNO);

ALTER TABLE #TABLE_NAME_UPPER# ADD CONSTRAINT PK_#TABLE_NAME_UPPER# PRIMARY KEY(#PK_COLUMNS#);

ALTER TABLE #TABLE_NAME_UPPER# ADD CONSTRAINT FK_USERS FOREIGN KEY(USERNO) REFERENCES USERS_INFO(USERNO);





ALTER TABLE O_GCAM.FB_PROPOSE ADD CONSTRAINT PK_FB_PROPOSE PRIMARY KEY (SUBJ,SUBJSEQ,USERID);

ALTER TABLE O_GCAM.FB_PROPOSE ADD CONSTRAINT SYS_C009881 CHECK ("SUBJ" IS NOT NULL);

ALTER TABLE O_GCAM.FB_PROPOSE ADD CONSTRAINT SYS_C009882 CHECK ("SUBJSEQ" IS NOT NULL);

ALTER TABLE O_GCAM.FB_PROPOSE ADD CONSTRAINT SYS_C009883 CHECK ("USERID" IS NOT NULL);

CREATE INDEX O_GCAM.IDX_FB_PROPOSE_01
    ON O_GCAM.FB_PROPOSE
        (
            USERID ASC
        )
    TABLESPACE TS_GCAM_D
    NOPARALLEL  
    PCTFREE 10
    INITRANS 2
    MAXTRANS 255
    STORAGE (
            INITIAL 64KB
            NEXT 1MB
            MINEXTENTS 1
            MAXEXTENTS 2147483645
            BUFFER_POOL DEFAULT
            );
            
            
            



            + "\n"
            + "ALTER TABLE O_GCAM.FB_KEYWORD ADD\n"
            + "(\n"
            + "    CONSTRAINT PK_FB_KEYWORD\n"
            + "    PRIMARY KEY ( GRCODE, KEYWORD )\n"
            + "        USING INDEX\n"
            + "        TABLESPACE TS_GCAM_X\n"
            + "        PCTFREE 10\n"
            + "        INITRANS 2\n"
            + "        MAXTRANS 255\n"
            + "        STORAGE (\n"
            + "            INITIAL 64 K\n"
            + "            NEXT 1 M\n"
            + "            MINEXTENTS 1\n"
            + "            MAXEXTENTS UNLIMITED\n"
            + "        )\n"
            + ");\n"
     
     */

    // length	
	maxLen = getMaxLen(table);

	// source
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
			if (col_str == "" ) {
				col_str += "( ";
			} else {
				col_str += ", ";
			}
			var colsize = "";
			if ( col.type == "TIMESTAME" || col.type == "DATE" || col.type == "BLOB" || col.type == "CLOB" ) {
			    colsize = "";
			}
			else {
    			if ( col.scale > 0) {
    			    colsize = "("  + (col.len + "").lpad(maxLen.len + col.scale + 1, ' ') + "." + col.scale + ")";
    			} else {
    			    colsize = "("  + (col.len + "").lpad(maxLen.len, ' ') + ")";
    			}
			}

            col_str = col_str + col.column.rpad(maxLen.column, ' ') + "    " + col.type.rpad(maxLen.type, ' ') + colsize;
            
            if ( col.nullable == 'N' ) {
                col_str = col_str + "    NOT NULL\n";
            } else {
                col_str = col_str + "        NULL\n";
            }

            desc_str = desc_str + "COMMENT ON COLUMN #OWNER#.#TABLE_NAME_UPPER#." + col.column.rpad(maxLen.column, ' ') + " IS '" + col.comment + "';\n";
		}
	}
// console.log(table);

    for ( var i = 0; i < table.indexes.length; i++ ) {
        var index = table.indexes[i];
        if ( index.index.startWith("PK_") ) {
            pk_index_str = pk_index_str + "ALTER TABLE " + table.owner + "." + table.name + " ADD CONSTRAINT " + index.index + " PRIMARY KEY (" + index.columns.join(", ") + ");"
        } else {
            pk_index_str = pk_index_str + "CREATE INDEX " + index.index + " ON " + table.name + "(" + index.columns.join(", ") + ");"; 
        }
    }
	col_str += ")\n\n";
    desc_str += "\n";
    

    tc_str = tc_str.replaceAll("#LOOP_COLUMN#", col_str);
    tc_str = tc_str.replaceAll("#LOOP_COLUMN_COMMENT#", desc_str);
    tc_str = tc_str.replaceAll("#PK_INDEX#", pk_index_str);
    tc_str = tc_str.replaceAll("#OWNER#", owner_name);
    tc_str = tc_str.replaceAll("#TABLE_NAME_UPPER#", table_name);
    tc_str = tc_str.replaceAll("#TABLE_NAME_DESC#", table_comment);
    
    code = tc_str;
	this.scope.output.target.result = code;
  }
};



