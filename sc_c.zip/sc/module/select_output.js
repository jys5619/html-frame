
gv_modules_output[gv_modules_output.length] = 
{ name: "SELECT"
 , options: [ {id:"COMMENT_PRINT", desc:"주석출력"            , value:false , display:true , type: "CHECKBOX"}
            , {id:"OWNER_PRINT"  , desc:"OWNER 출력"         , value:false , display:true , type: "CHECKBOX"}
            , {id:"WHERE_ONE"    , desc:"WHERE 1 = 1 출력"   , value:false , display:true , type: "CHECKBOX"}
            , {id:"WHERE_PREFIX" , desc:"WHERE절 변수 앞문자" , value:"#{"  , display:true , type: "TEXT"}
            , {id:"WHERE_SUFFIX" , desc:"WHERE절 변수 뒷문자" , value:"}"   , display:true , type: "TEXT"}
            , {id:"MYBATIS_PRINT", desc:"Mybatis XML 출력"   , value:true , display:true , type: "CHECKBOX"}
            , {id:"CAMEL_CASE"   , desc:"Camel 형식 출력"    , value:true    , display:true , type: "CHECKBOX"}
            , {id:"INTO_PRINT"   , desc:"INTO 구문 출력"     , value:false , display:true , type: "CHECKBOX"}
            , {id:"INTO_PREFIX"  , desc:"INTO 앞문자"        , value:":"   , display:true , type: "TEXT"}
            , {id:"INTO_SUFFIX"  , desc:"INTO 뒤문자"        , value:""   , display:true , type: "TEXT"}
            ]
 , fnGetSource: function () {
     var table = this.scope.processer[this.scope.input.target].target;

	var code       = "";
	var col        = null;
	var tblName    = "";
	var varType    = "";
	var varUType   = "";
    
	var maxLen     = null;
	var space      = 0;
	
	var mybatisStr = "";
	var selectStr  = "";
	var intoStr    = "";
	var fromStr    = "";
	var whereStr   = "";

    var idx = 0;
       
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "COMMENT_PRINT";
    });
    var comment_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "OWNER_PRINT";
    });
    var owner_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "WHERE_ONE";
    });     
    var where_one = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "WHERE_PREFIX";
    });     
    var where_prefix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "WHERE_SUFFIX";
    });     
    var where_suffix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "MYBATIS_PRINT";
    });     
    var mybatis_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "CAMEL_CASE";
    });     
    var camel_case = this.scope.output.target.options[idx].value;
    
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "INTO_PRINT";
    });
    var into_print = this.scope.output.target.options[idx].value;
     
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "INTO_PREFIX";
    });     
    var into_prefix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "INTO_SUFFIX";
    });     
    var into_suffix = this.scope.output.target.options[idx].value;
     
    if ( camel_case ) {
        varType = "camel";
        varUType = "Camel";
    } else {
        varType = "lower";
        varUType = "upper";
    }
     
    // length	
	maxLen = getMaxLen(table);

    space = maxLen.column;

	if ( into_print ) {
		space = space + into_prefix.length + into_suffix.length + 1;
	}

	tblName = getFullName(owner_print, table.owner, table.name, "");
    
	if ( space < tblName.length ) {
		space = tblName.length;
	}
    
    if ( typeof table.comments == "undefined" ) {
        table.comments = "";
    }
    if ( typeof table.name == "undefined" ) {
        table.name = "";
    }
    if ( maxLen.comment < table.comments.bytelength() ) {
        maxLen.comment = table.comments.bytelength();
    }
	
	// source
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
			if (selectStr == "" ) {
				selectStr += "SELECT /* " + table.name.toCase(varUType) + "Mapper.select" + table.name.toCase(varUType) + " */\n       ";
			} else {
				selectStr += "     , ";
			}

            if ( comment_print ) {
                selectStr = selectStr + col.column.rpad(space, ' ') + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
            } else {
                selectStr = selectStr + col.column + "\n";
            }
			
			if ( into_print ) {
				if ( intoStr == "" ) {
					intoStr += "  INTO ";
				} else {
					intoStr += "     , ";
				}
				
                if ( comment_print ) {
				    intoStr = intoStr + (into_prefix + col.column.toCase(varType) + into_suffix).rpad(space, ' ') + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
                } else {
                    intoStr = intoStr + (into_prefix + col.column.toCase(varType) + into_suffix) + "\n";
                }
			}
		}
	}
	
    if ( comment_print ) {
        fromStr  = "  FROM " + tblName.rpad(space, ' ') + "    /* " + table.comments.byterpad(maxLen.comment, ' ') + " */\n";
    } else {
        fromStr  = "  FROM " + tblName.rpad(space, ' ') + "\n";
    }
    
    if ( table.index != null ) {
        for ( var i = 0; i < table.index.columnlist.length; i++ ) {
            if (whereStr == "") {
                if ( where_one ) {
                    whereStr =" WHERE 1 = 1\n   AND ";
                } else {
                    whereStr =" WHERE ";
                }
            } else {
                    whereStr +="   AND ";
            }
            col = table.index.columnlist[i];

            if ( comment_print ) {
                whereStr = whereStr + col.column.rpad(maxLen.index, ' ') + " = " + where_prefix + (col.column.toCase(varType) + where_suffix).rpad(maxLen.indexCamel + where_suffix.length, ' ') + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
            } else {
                whereStr = whereStr + col.column.rpad(maxLen.index, ' ') + " = " + where_prefix + col.column.toCase(varType) + where_suffix + "\n";
            }
        }
    }
     
	code = selectStr + intoStr + fromStr + whereStr;
     
    if (mybatis_print) {
        mybatisStr = '\n    <!-- ' + table.comments + ' 조회 -->\n' + '    <select id="select' + table.name.toCase(varUType) + '" parameterType="' + table.name.toCase(varUType) + 'Vo" resultType="' + table.name.toCase(varUType) + 'Vo">\n'

        code.split("\n").forEach(function (line) {
            if ( line.trim().length > 0 ) {
                mybatisStr = mybatisStr + "        " + line + "\n";
            }
        });
        
        mybatisStr = mybatisStr + '    </select>\n'
        code = mybatisStr;
    }
     
	this.scope.output.target.result = code;
  }
};



