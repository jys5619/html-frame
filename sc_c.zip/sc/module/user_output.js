
gv_modules_output[gv_modules_output.length] = 
{ name: "USER_OUTPUT"
 , options: [ {id:"COMMENT_PRINT", desc:"주석출력"        , value:false    , display:true , type: "CHECKBOX"}
            , {id:"TO_VO"        , desc:"TO VO"           , value:"vo"   , display:true , type: "TEXT"}
            , {id:"FR_VO"        , desc:"FROM VO"         , value:"fromVo" , display:true , type: "TEXT"}
            , {id:"TOJSON_PRINT" , desc:"Json Vo 출력"    , value:false     , display:true , type: "CHECKBOX"}
            , {id:"JSON_STRVO_PRINT" , desc:"Json Stiring 출력"    , value:true     , display:true , type: "CHECKBOX"}
            , {id:"JSON_STRVO_DESC" , desc:"Json Stiring 주석"    , value:true     , display:true , type: "CHECKBOX"}
            , {id:"SETJSON_PRINT", desc:"JsonData 출력", value:true     , display:true , type: "CHECKBOX"}
            , {id:"SETJSON_DESC", desc:"JsonData 주석", value:true     , display:true , type: "CHECKBOX"}
            , {id:"VO_COPY"      , desc:"VO객체 복사"     , value:false     , display:true , type: "CHECKBOX"}
            , {id:"RES_PRINT"      , desc:"RES SOAP"     , value:false     , display:true , type: "CHECKBOX"}
            , {id:"FAKE_JSON"    , desc:"가짜 JSON문자"   , value:false     , display:true , type: "CHECKBOX"}
            , {id:"INSERT_QUERY" , desc:"INSERT QUERY"   , value:false     , display:true , type: "CHECKBOX"}
            , {id:"FROM_TABLE"   , desc:"FROM_TABLE"   , value:"FROM_TABLE"     , display:true , type: "TEXT"}
            , {id:"TO_TABLE"     , desc:"TO_TABLE"   , value:"TO_TABLE"     , display:true , type: "TEXT"}
  ]
 , fnGetSource: function (target, processer) {
    var table = this.scope.processer[this.scope.input.target].target;
    var code       = "";
	var col        = null;
	var tblName    = "";
	var space      = 0;
	var maxLen     = null;
	var varType    = "";
	var varUType   = "";
    var toStr      = "";
    var jsonStr    = "";
    var voCopyStr  = "";
    var fakeJsonStr = "";
    var fakeJsonStr2 = "";
    var insertQUery = "";
	var insertColumn = "";
	var insertValue = "";
	var jsonstrvo = "";
	
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "COMMENT_PRINT";
    });
    var comment_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "TO_VO";
    });
    var to_vo = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "FR_VO";
    });
    var fr_vo = this.scope.output.target.options[idx].value;
          
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "TOJSON_PRINT";
    });
    var toJson_print = this.scope.output.target.options[idx].value;
          
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "JSON_STRVO_PRINT";
    });
    var json_strvo_print = this.scope.output.target.options[idx].value;
    
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "JSON_STRVO_DESC";
    });
    var json_strvo_desc = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "SETJSON_PRINT";
    });
    var setJson_print = this.scope.output.target.options[idx].value;
    
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "SETJSON_DESC";
    });
    var setJson_desc = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "VO_COPY";
    });
    var vo_copy = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "FAKE_JSON";
    });
    var fake_json = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "RES_PRINT";
    });
    var res_print = this.scope.output.target.options[idx].value;
    
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "INSERT_QUERY";
    });
    var insert_query = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "FROM_TABLE";
    });
    var from_table = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "TO_TABLE";
    });
    var to_table = this.scope.output.target.options[idx].value;
     
	// length
	maxLen = getMaxLen(table);
     
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
            if ( toJson_print ) {
                if ( toStr != "" ) {
                    toStr += "+ \",\\\""
                } else {
                    toStr = "= \"{\\\"";
                }
                
                if ( col.type == "NUMBER" || col.type == "FLOAT" ) {
                    toStr = toStr + (col.column + "\\\": \"").rpad(maxLen.column + 7, ' ') + " + " + to_vo + ".get" + col.column.toCamelCase().toFirstUpperCase() + "()\n";
                } else {
                    toStr = toStr + (col.column + "\\\": \\\"\"").rpad(maxLen.column + 7, ' ') + " + " + to_vo + ".get" + (col.column.toCamelCase().toFirstUpperCase() + "()").rpad(maxLen.columnCamel+ 2, ' ') + " + \"\\\"\"\n";
                }
            }
            
            if ( setJson_print ) {
                if ( setJson_desc ) {
                    jsonStr = jsonStr + to_vo + ".set" + col.column.toCamelCase().toFirstUpperCase().rpad(maxLen.columnCamel, ' ') + "(jsonData.get" + fnGetType(col, "javaObject").rpad(7, ' ') + "(\"" + (col.column + "\"").rpad(maxLen.column + 1, ' ') + "));    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
                } else {
                    jsonStr = jsonStr + to_vo + ".set" + col.column.toCamelCase().toFirstUpperCase().rpad(maxLen.columnCamel, ' ') + "(jsonData.get" + fnGetType(col, "javaObject").rpad(7, ' ') + "(\"" + (col.column + "\"").rpad(maxLen.column + 1, ' ') + "));\n";
                }

            }
                
            
            if ( json_strvo_print ) {
                
                //jsonstrvo = jsonstrvo + "				sb.append(Util.getJsonString(" + ("\"" + col.column + "\"").rpad(maxLen.column+2, ' ') + ", vo.get" + (col.column.toCase("Camel") + "()").rpad(maxLen.columnCamel+2, " ") + "));\n"
                if ( json_strvo_desc ) {
                    jsonstrvo = jsonstrvo + "                             .add(" + ("\"" + col.column + "\"").rpad(maxLen.column+2, ' ') + ", vo.get" + (col.column.toCase("Camel") + "()").rpad(maxLen.columnCamel+2, " ") + ")\n";
                } else {
                    jsonstrvo = jsonstrvo + "                             .add(" + ("\"" + col.column + "\"").rpad(maxLen.column+2, ' ') + ", vo.get" + (col.column.toCase("Camel") + "()").rpad(maxLen.columnCamel+2, " ") + ")\n";
                }
            }
            
            if ( vo_copy ) {
                voCopyStr = voCopyStr + to_vo + ".set" + col.column.toCamelCase().toFirstUpperCase().rpad(maxLen.columnCamel, ' ') + "(" + fr_vo + ".get" + (col.column.toCamelCase().toFirstUpperCase() + "()").rpad(maxLen.columnCamel+2, ' ') + ");\n";
            }
            
            if ( fake_json ) {
                if ( fakeJsonStr != "" ) {
                    fakeJsonStr += ",\""
                    fakeJsonStr2 += ",\""
                } else {
                    fakeJsonStr = "{\"";
                    fakeJsonStr2= "{\"";
                }

                fakeJsonStr = fakeJsonStr + col.column + "\": \"" + getFaceData(col) + "\"\n";
                fakeJsonStr2 = fakeJsonStr2 + col.column + "\": \"" + getFaceData(col) + "\"\n";

            }
            
            if ( insert_query ) {
                insertColumn = insertColumn + col.column + ", ";
                if ( col.type == "NUMBER" || col.type == "INTEGER" || col.type == "FLOAT" || col.type == "DOUBLE" ) {
                    insertValue = insertValue + " || NVL(TO_CHAR(" + col.column + "), 'NULL')"  + " || ', '";
                } else {
                    if ( col.column == "IF_SYNC_DTTM" ) {
                        insertValue = insertValue + " || 'TO_CHAR(SYSDATE, ''YYYYMMDDHH24MISS'')' || ', '";
                    } else {
                        insertValue = insertValue + " || '''' || " + col.column + " || '''' || ', '";
                    }
                }
            }
		}
    }
    if ( insert_query ) {
        insertColumn = insertColumn.trim();
        insertValue = insertValue.trim();
        if ( insertColumn.endWith(",") ) {
            insertColumn = insertColumn.substr(0, insertColumn.length -1 );
            insertValue = insertValue.substr(0, insertValue.length - 8 );
        }
        insertQUery = "SELECT\n       'INSERT   INTO " + to_table + " ( " + insertColumn + ") VALUES ( ' " + insertValue + " || ');' AS QUERY\n  FROM " + from_table;
    }
    
    if ( toJson_print ) {
        toStr += "+ \"}\"\n";
    }
    
    if ( json_strvo_print ) {
        jsonstrvo = "                   jsonString.start()\n" + jsonstrvo + "                             .end();\n";
    }
    
    if ( fake_json ) {
        fakeJsonStr = "{\"DATA\" : {\"RLT_CODE\": \"000\",\"RLT_MSG\": \"SUCCESS\",\"RLT_RCNT\": \"2\"},\"RECORD\" : [\n" + fakeJsonStr + "}, \n" + fakeJsonStr2 + "}\n]}";
    }

    code = jsonStr + "\n\n" + toStr + "\n\n" + voCopyStr + "\n\n" + fakeJsonStr + "\n\n" + jsonstrvo + "\n\n" + insertQUery;
	this.scope.output.target.result = code.trim();
 }
};

function getFaceData(col) {
    var str = "";
    if ( col.type == "FLOAT" ) {
        str = randomNumber(0, 10000) + "." + randomNumber(0, 100);
    } else if ( col.type == "NUMBER" ) {
        if (col.scale > 0) {
            str = randomNumber(0, 10000) + "." + randomNumber(0, 100);
        } else if (col.len > 9) {
            str = randomNumber(0, 90000);
        } else {
            str = randomNumber(0, 90000);
        }
    } else {
        if ( col.len > 10 ) {
            str = randomString(col.len / 2 - randomNumber(0, col.len / 2));
        } else {
            if ( col.len > 40 ) {
                str = randomString(20);
            } else {
                str = randomString(col.len / 2);
            }
        }
    }
        
    return str;
}


