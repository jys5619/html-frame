
gv_modules_output[gv_modules_output.length] = 
{ name: "VO"
 , options: [ {id:"COMMENT_PRINT", desc:"주석출력"       , value:false , display:true , type: "CHECKBOX"}
            , {id:"GET_PRINT"    , desc:"GET 함수 출력"  , value:true , display:true, type: "CHECKBOX"}
            , {id:"SET_PRINT"    , desc:"SET 함수 출력"  , value:true    , display:true , type: "CHECKBOX"}          
            , {id:"TO_STR_PRINT" , desc:"toString 출력"     , value:true , display:true , type: "CHECKBOX"}
  ]
 , fnGetSource: function (target, processer) {
    var table = this.scope.processer[this.scope.input.target].target;
    var code       = "";
	var col        = null;
	var tblName    = "";
	var space      = 0;
	var maxLen     = null;
	var voStr      = "";
	var fnStr      = "";
    var toStr      = "";
    var jsonStr    = "";
	var classStr   = "";
	
	var varType    = "";
	var varUType   = "";
	
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "COMMENT_PRINT";
    });
    var comment_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "GET_PRINT";
    });
    var get_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "SET_PRINT";
    });
    var set_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "TO_STR_PRINT";
    });
    var to_str_print = this.scope.output.target.options[idx].value;
     
    if ( typeof table.name == "undefined" ) {
        table.name = "";
    }
    
	// length
	maxLen = getMaxLen(table);
     
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
            if ( comment_print ) {
                voStr = voStr + "\tprivate " + fnGetType(col, "javaObject").rpad(7, ' ') + (col.column.toCamelCase() + ";").rpad(maxLen.column + 1, ' ') + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
            } else {
                voStr = voStr + "\tprivate " + fnGetType(col, "javaObject").rpad(7, ' ') + col.column.toCamelCase() + ";\n";
            }
            
            if ( get_print ) {
                if ( comment_print ) {
                    fnStr = fnStr + "\t/**\n"
                                  + "\t * " + col.comment + "\n"
                                  + "\t * @return\n"
                                  + "\t */\n"
                                  + "\tpublic " + fnGetType(col, "javaObject") + " get" + col.column.toCamelCase().toFirstUpperCase() + "() {\n"
                                  + "\t\treturn " + col.column.toCamelCase() + ";\n"
                                  + "\t}\n";
                } else {
                    fnStr = fnStr + "\tpublic " + fnGetType(col, "javaObject") + " get" + col.column.toCamelCase().toFirstUpperCase() + "() {\n"
                                  + "\t\treturn " + col.column.toCamelCase() + ";\n"
                                  + "\t}\n";
                }
            }
            
            if ( get_print ) {
                if ( comment_print ) {
                    fnStr = fnStr + "\t/**\n"
                                  + "\t * " + col.comment + "\n"
                                  + "\t * @param " + col.column.toCamelCase() + "\n"
                                  + "\t */\n"
                                  + "\tpublic void set" + col.column.toCamelCase().toFirstUpperCase() + "(" + fnGetType(col, "javaObject") + " " + col.column.toCamelCase() + ") {\n"
                                  + "\t\tthis." + col.column.toCamelCase() + " = " +  col.column.toCamelCase() + ";\n"
                                  + "\t}\n";    
                } else {
                    fnStr = fnStr + "\tpublic void set" + col.column.toCamelCase().toFirstUpperCase() + "(" + fnGetType(col, "javaObject") + " " + col.column.toCamelCase() + ") {\n"
                                  + "\t\tthis." + col.column.toCamelCase() + " = " +  col.column.toCamelCase() + ";\n"
                                  + "\t}\n";   
                }
            }
            
            if ( to_str_print ) {
                if ( toStr == "" ) {
                    toStr  = "\t\tsb.append(\"";
                } else {
                    toStr += ".append(\", \")\n\t\t  .append(\"";
                }
                
                toStr = toStr + col.column.rpad(maxLen.column, ' ') + ":[\").append(" + col.column.toCamelCase().rpad(maxLen.columnCamel, ' ') + ").append(\"]\")";
            }
		}
    }
    
    if ( to_str_print && toStr != "" ) {
        toStr = "\t@Override\n"
              + "\tpublic String toString() {\n"
              + "\t\tStringBuffer sb = new StringBuffer();\n"
              + toStr
              + "\n\t\t;\n"
              + "\t\treturn sb.toString();\n"
              + "\t}\n"
              ;
        
    }

    if ( comment_print ) {
        classStr = "/**\n"
                 + " *\n"
                 + " * " + table.name + " - " + table.comments + "\n"
                 + " *\n"
                 + " */\n"
                 + "public class " + table.name.toCamelCase().toFirstUpperCase() + "Vo { \n";
    } else {
        classStr = "public class " + table.name.toCamelCase().toFirstUpperCase() + "Vo { \n";
    }

    code = classStr + voStr + fnStr + toStr + "}";
	this.scope.output.target.result = code;
 }
};
	