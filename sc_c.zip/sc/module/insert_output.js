

gv_modules_output[gv_modules_output.length] = 
{ name: "INSERT"
 , options: [ {id:"COMMENT_PRINT", desc:"주석출력"            , value:false , display:true , type: "CHECKBOX"}
            , {id:"VALUE_PREFIX" , desc:"VALUE절 변수 앞문자"  , value:"#{item." , display:true , type: "TEXT"}
            , {id:"VALUE_SUFFIX" , desc:"VALUE절 변수 뒷문자"  , value:"}"  , display:true , type: "TEXT"}
            , {id:"OWNER_PRINT"  , desc:"OWNER 출력여부"      , value:false , display:true, type: "CHECKBOX"}
            , {id:"MYBATIS_PRINT", desc:"Mybatis XML 출력"   , value:true , display:true , type: "CHECKBOX"}
            , {id:"CAMEL_CASE"   , desc:"Camel 형식 출력"    , value:true    , display:true , type: "CHECKBOX"}
  ]
 , fnGetSource: function (target, processer) {
    var table = this.scope.processer[this.scope.input.target].target;
    var code       = "";
	var col        = null;
	var tblName     = "";
	var space      = 0;
	var maxLen     = null;
	var insertStr  = "";
	var valuesStr  = "";
    var mybatisStr = "";
	var varType    = "";
	var varUType   = "";
    var varLen     = 0;
    var null_str   = "";
	
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "COMMENT_PRINT";
    });
    var comment_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "VALUE_PREFIX";
    });
    var value_prefix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "VALUE_SUFFIX";
    });
    var value_suffix = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "OWNER_PRINT";
    });
    var owner_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "MYBATIS_PRINT";
    });     
    var mybatis_print = this.scope.output.target.options[idx].value;
     
    idx = this.scope.output.target.options.findIndex(function(option) {
        return option.id == "CAMEL_CASE";
    });     
    var camel_case = this.scope.output.target.options[idx].value;
    
	// length
	maxLen = getMaxLen(table);

    if ( camel_case ) {
        varType = "camel";
        varUType = "Camel";
        varLen = maxLen.columnCamel;
    } else {
        varType = "lower";
        varUType = "upper";
        varLen = maxLen.column;
    }
     
    space = maxLen.column + value_prefix.length + value_suffix.length;
    
	tblName = getFullName(owner_print, table.owner, table.name, "");
    
	if ( space < tblName.length ) {
		space = tblName.length;
	}
	
	if ( maxLen.comment < table.comments.bytelength() ) {
	    maxLen.comment = table.comments.bytelength();
	}
	
	// source
	for ( var i = 0; i < table.columns.length; i++ ) {
		col = table.columns[i];
		if ( col.checked ) {
			if (insertStr == "" ) {
                if ( comment_print ) {
				    insertStr += "INSERT /* " + table.name.toCase(varUType) + "Mapper.insert" + table.name.toCase(varUType) + " */\n  INTO " + (tblName).rpad(space, ' ') + "    /* " + table.comments.byterpad(maxLen.comment, ' ') + " */\n     ( ";
                } else {
                    insertStr += "INSERT /* " + table.name.toCase(varUType) + "Mapper.insert" + table.name.toCase(varUType) + " */\n  INTO " + tblName + "\n     ( ";
                }
			} else {
				insertStr += "     , ";
			}

            if ( comment_print ) {
			    insertStr = insertStr + col.column.rpad(space, ' ') + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
            } else {
                insertStr = insertStr + col.column + "\n";
            }
			
			if (valuesStr == "" ) {
				valuesStr += "VALUES\n     ( ";
			} else {
				valuesStr += "     , ";
			}
            
            if ( col.nullable == 'Y' ) {
                null_str = ", jdbcType=" + fnGetType(col, "jdbcType");
            } else {
                null_str = "";
            }

            if ( comment_print ) {
			    valuesStr = valuesStr + value_prefix + col.column.toCase(varType).rpad(varLen, ' ') + null_str + value_suffix + "    /* " + col.comment.byterpad(maxLen.comment, ' ') + " */\n";
            } else {
			    
			    
                
                if ( col.nullable == 'Y' ) {
                    null_str = ", jdbcType=" + fnGetType(col, "jdbcType");
                    valuesStr = valuesStr + value_prefix + col.column.toCase(varType).rpad(varLen, ' ') + null_str + value_suffix + "\n";
                } else {
                    valuesStr = valuesStr + value_prefix + col.column.toCase(varType) + value_suffix + "\n";
                }
            }
		}
	}

	code = insertStr + "     )\n" + valuesStr + "     )";
	
    if (mybatis_print) {
        mybatisStr = '\n    <!-- ' + table.comments + ' 등록 -->\n' + '    <insert id="insert' + table.name.toCase(varUType) + '" parameterType="' + table.name.toCase(varUType) + 'Vo">\n'
        code.split("\n").forEach(function (line) {
            if ( line.trim().length > 0 ) {
                mybatisStr = mybatisStr + "        " + line + "\n";
            }
        });
        
        mybatisStr = mybatisStr + '    </insert>\n'
        code = mybatisStr;
    }
     
	this.scope.output.target.result = code;
 }
};
