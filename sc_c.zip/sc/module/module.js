
function getMaxLen(table) {
    var col    = null;
	var pos    = 1;
	var maxLen = {};
	maxLen.column      = 0;
	maxLen.type        = 0;
	maxLen.columnCamel = 0;
	maxLen.comment     = 0;
	maxLen.len         = 0;
	maxLen.scale       = 0;
	maxLen.pos         = 1;
	maxLen.index       = 0;
	maxLen.indexCamel  = 0;
	
    if ( table.columns != null ) {
        for ( var i = 0; i < table.columns.length; i++ ) {
            col = table.columns[i];
            if ( col.checked ) {
                if ( typeof col.column != "undefined" && maxLen.column < col.column.length ) {
                    maxLen.column = col.column.length;
                }
                
                if ( typeof col.type != "undefined" && maxLen.type < col.type.length ) {
                    maxLen.type = col.type.length;
                }

                if ( typeof col.comment != "undefined" && maxLen.comment < col.comment.bytelength() ) {
                    maxLen.comment = col.comment.bytelength();
                }

                if ( typeof col.len != "undefined" && maxLen.len < (col.len + "").length ) {
                    maxLen.len = (col.len + "").length;
                }

                if ( typeof col.scale != "undefined" && col.scale > 0 && maxLen.scale < (col.scale + "").length ) {
                    maxLen.scale = (col.scale + "").length;
                }

                if ( typeof col.column != "undefined" && maxLen.columnCamel < col.column.replaceAll("_", "").length ) {
                    maxLen.columnCamel = col.column.replaceAll("_", "").length;
                }
                pos += col.len;
            }
        }
        
	    maxLen.pos = (pos + "").length;
    }
	
    if ( table.index != null ) {
        for ( var i = 0; i < table.index.columnlist.length; i++ ) {
            col = table.index.columnlist[i];
            if ( typeof col.column != "undefined" && maxLen.index < col.column.length ) {
                maxLen.index = col.column.length;
            }
            
            if ( typeof col.column != "undefined" && maxLen.indexCamel < col.column.replaceAll("_", "").length ) {
                maxLen.indexCamel = col.column.replaceAll("_", "").length;
            }
        }
        
	    maxLen.pos = (pos + "").length;
    }
	

	return maxLen;
}

function getFullName(is_owner_print, owner, table, alias) {
    var str = "";
    if ( table != "" ) {
        
        if ( is_owner_print ) {
    	    if ( owner != "" && !owner.endWith(".") ) {
    	        str = owner + ".";
    	    } else {
    	        str = owner;
    	    }
    	}
	    
	    str = str + table;
	    
	    if ( alias != "" ) {
	        str = str + " " + alias;
	    }
	} else {
	    str = "DUAL";
	}
    return str;
}


function fnGetType(col, programName) {
    if ( programName == "java" ) {
        return fnGetJavaType(col);
    }
    if ( programName == "javaObject" ) {
        return fnGetJavaObjectType(col);
    }
    if ( programName == "jdbcType" ) {
        return fnGetJdbcType(col);
    }
}

function fnGetJavaObjectType(col) {
    var str = "";
    if ( col.type == "FLOAT" ) {
        str = "Double";
    } else if ( col.type == "NUMBER" ) {
        if (col.scale > 0) {
            str = "Double";
        } else if (col.len > 9) {
            str = "Long";
        } else {
            str = "Integer";
        }
    } else {
        str = "String";
    }
        
    return str;
}

function fnGetJavaType(col) {
    var str = "";
    if ( col.type == "FLOAT" ) {
        str = "double";
    } else if ( col.type == "NUMBER" ) {
        if (col.scale > 0) {
            str = "double";
        } else if (col.len > 9) {
            str = "long";
        } else {
            str = "int";
        }
    } else {
        str = "String";
    }
        
    return str;
}

function fnGetJdbcType(col) {

    var str = "";
    if ( col.type == "FLOAT" ) {
        str = "DOUBLE";
    } else if ( col.type == "NUMBER" ) {
        if (col.scale > 0) {
            str = "DOUBLE";
        } else if (col.len > 9) {
            str = "NUMERIC";
        } else {
            str = "INTEGER";
        }
    } else if ( col.type == "TIMESTAMP" ) {
        str = "TIMESTAMP";
    } else if ( col.type == "DATE" ) {
        str = "DATE";
    } else {
        str = "VARCHAR";
    }
        
    return str;
}
/*
BIT
FLOAT
CHAR
TIMESTAMP
OTHER
UNDEFINED
TINYINT
REAL
VARCHAR
BINARY
BLOB
NVARCHAR
SMALLINT
DOUBLE
LONGVARCHAR
VARBINARY
CLOB
NCHAR
INTEGER
NUMERIC
DATE
LONGVARBINARY
BOOLEAN
NCLOB
BIGINT
DECIMAL
TIME
NULL
CURSOR
*/


if ( typeof(gv_modules_output) === "undefined" ) {
    gv_modules_output = [];
}

gv_modules_output[gv_modules_output.length] = 
{ name: "ETC"
 , options: [ {id:"VALUE_PREFIX" , desc:"INTO 구문 출력여부"  , value:false , display:true, type: "CHECKBOX"}
            , {id:"VALUE_SUFFIX" , desc:"INTO 앞문자"        , value:""    , display:true , type: "TEXT"}
            , {id:"INTO_SUFFIX" , desc:"INTO 뒷문자"        , value:""    , display:true , type: "TEXT"}
            , {id:"WHERE_PREFIX", desc:"WHERE절 변수 앞문자" , value:"#{"  , display:true , type: "TEXT"}
            , {id:"WHERE_SUFFIX", desc:"WHERE절 변수 뒷문자" , value:"}"   , display:true , type: "TEXT"}
            , {id:"OWNER_PRINT" , desc:"OWNER 출력여부"     , value:true  , display:true , type: "CHECKBOX"}
            , {id:"OWNER_PRINT" , desc:"조인테이블"         , value:"A"   , display:true , type: "COMBOBOX", list:[{value:"A", desc:"FB_A"}, {value:"B" ,desc:"FB_B"}, {value:"C", desc:"FB_C"}]}
  ]
 , fnGetSource: function (target, processer) {
	this.scope.output.target.result = "TEST";
 }
};


if ( typeof(gv_modules_input) === "undefined" ) {
    var gv_modules_input = [];
}


gv_modules_input[gv_modules_input.length] = 
{ name: "SELECT"
, is: function(str) {
      return str.trim().toUpperCase().startWith("SELECT");
  }
, process: function(str) {
	var data      = [];
	var content   = "";
	var selectStr = "";
	var fromStr   = "";
	var arrTmp    = null;
	var col       = "";
	var cols      = [];
    var tbls      = [];
	
	content = str.replaceRange("/*", "*/", " ");
	content = content.replaceRange("//", "\r\n", " ");
	content = content.replaceRange("'", "'", " _NONE_ ");
	content = content.loopCutRange("(", ")", " _NONE_ ");
	content = content.replace(/\r\n/gi, " ");
	content = content.replace(/\t/gi, " ");
	content = " " + content + " ";
	content = content.removeDblSpace();
	
	var selectIdx = content.indexOf(" SELECT ");
	var fromIdx   = content.indexOf(" FROM "  );
	var whereIdx  = content.indexOf(" WHERE " );
	
	if ( fromIdx < 0  ) {
		selectStr = content.substr(selectIdx + 8, content.length - selectIdx - 8);
	} else {
		selectStr = content.substr(selectIdx + 8, fromIdx - selectIdx - 8);

         if ( whereIdx < 0 ) {
             fromStr = content.substr(fromIdx + 6, content.length - fromIdx - 6);
         } else {
             fromStr = content.substr(fromIdx + 6, whereIdx - fromIdx - 6);
         }
    }

    // table
    /*
    if ( fromStr.trim() != "" && fromStr.indexOf(",") < 0 ) {
        data.setTable(fromStr);
    
    }
    */

    // column
    cols = selectStr.split(",");

    for ( var i = 0; i < cols.length; i++ ) {
        arrTmp = cols[i].trim().split(" ");
        col = arrTmp[arrTmp.length - 1].trim();
        
        if ( col == "_NONE_" ) {
            col = "";
        } 
        data[data.length] = {"table":"", alias:"", "column":col};
    }
    return data;
  }
};

	