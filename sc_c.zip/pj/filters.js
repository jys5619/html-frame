angular.module('sc').filter('lpad', function(){
    return function(input, len, chr){
        input = input.toString();
        while( input.length < len ) {
            input = chr + input;
        }
        return input;
    };
});

angular.module('sc').filter('rpad', function(){
    return function(input, len, chr){
        input = input.toString();
        while( input.length < len ) {
            input = input + chr;
        }
        return input;
    };
});


angular.module('sc').filter('replace', function(){
    return function(input, searchStr, replaceStr){
        input = input.toString();
        return input.split(searchStr).join(replaceStr);
    };
});
