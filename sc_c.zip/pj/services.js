angular.module('pj').factory('pjDb', function() {
    var storage = {
        projectList: [],
        setProjectList: function(data) {
            angular.copy(data, storage.projectList) || [];
        },
        getProjectList: function() {
            return storage.projectList;
        }
    };
    
    return storage;
});
