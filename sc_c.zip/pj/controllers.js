angular.module('pj', ['angular.filter']).controller('PjCtrl', function($scope, $http, pjDb) {

    $http.get("./repository/project_list.js").then( 
        function(response) {
            pjDb.setProjectList(response.data);
        }
      , function(response) {
            alert("Something went wrong");
        }
    );
    
    
    // input
    $scope.projectList = [];
    $scope.projectList = pjDb.getProjectList();
    
    $scope.fnAlert = function(source) {
        alert(typeof(source));
        $scope.sourceList = source;
        $scope.targetSource = $scope.sourceList[0];
    };
    $scope.fnSorceTabClick = function(source) {
      $scope.targetSource  = source;
    } 
});

